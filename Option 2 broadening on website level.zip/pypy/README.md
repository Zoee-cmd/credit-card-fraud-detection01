# CBZ Bank Fraud Analyst Dashboard

A comprehensive fraud analysis and transaction management system for CBZ Bank's administrative team.

## Features

- Secure admin authentication with OTP verification
- Real-time transaction monitoring
- Customer record management
- Fraud detection and risk analysis
- Credit card testing interface
- Payment link generation
- Responsive design for all devices

## Tech Stack

- Backend: Flask (Python)
- Frontend: HTML5, CSS3, JavaScript
- Database: SQLite (SQLAlchemy)
- Authentication: Flask-Login
- UI Framework: Bootstrap 5

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/cbz-bank-dashboard.git
cd cbz-bank-dashboard
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Initialize the database:
```bash
flask db init
flask db migrate
flask db upgrade
```

5. Run the application:
```bash
python app.py
```

The application will be available at `http://localhost:5000`

## Project Structure

```
cbz-bank-dashboard/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── static/               # Static files
│   ├── css/             # CSS stylesheets
│   │   └── admin.css    # Admin dashboard styles
│   └── js/              # JavaScript files
│       └── admin.js     # Admin dashboard scripts
├── templates/            # HTML templates
│   ├── admin_login.html # Admin login page
│   ├── admin_otp.html   # OTP verification page
│   └── admin_dashboard.html # Main dashboard
└── models/              # Database models
    └── __init__.py     # Model definitions
```

## Security Features

- Two-factor authentication with OTP
- Session management
- CSRF protection
- Secure password handling
- Rate limiting
- Input validation

## API Endpoints

### Authentication
- `POST /admin/login` - Admin login
- `POST /admin/otp` - OTP verification
- `GET /admin/logout` - Admin logout

### Transactions
- `GET /api/transactions` - Get all transactions
- `GET /api/transaction/<id>` - Get transaction details
- `POST /api/transaction/<id>/status` - Update transaction status

### Customers
- `GET /api/customers` - Get all customers
- `GET /api/customer/<id>` - Get customer details
- `POST /api/customer/<id>/flag` - Toggle customer flag status

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@cbzbank.com or create an issue in the repository. 