<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'fraud_detection';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode(['error' => 'Connection failed: ' . $e->getMessage()]);
    exit();
}

// Function to log transaction
function logTransaction($pdo, $data) {
    try {
        $stmt = $pdo->prepare("INSERT INTO transactions (amount, location, merchant, prediction, probability, timestamp) 
                              VALUES (:amount, :location, :merchant, :prediction, :probability, :timestamp)");
        
        $stmt->execute([
            ':amount' => $data['amount'],
            ':location' => $data['location'],
            ':merchant' => $data['merchant'],
            ':prediction' => $data['prediction'],
            ':probability' => $data['probability'],
            ':timestamp' => date('Y-m-d H:i:s')
        ]);
        
        return true;
    } catch(PDOException $e) {
        return false;
    }
}

// Function to get transaction history
function getTransactionHistory($pdo, $limit = 100) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM transactions ORDER BY timestamp DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        return [];
    }
}
?> 