from flask import Flask, request, jsonify, render_template, session, redirect, url_for, flash, get_flashed_messages
from flask_login import login_user, login_required, logout_user, current_user
import os
from datetime import datetime, timedelta
import random
import string
import secrets
from extensions import db, login_manager
from models.user import User
from models.transaction import Transaction
from models.payment_link import PaymentLink
from functools import wraps
import re
from models.settings import Settings
import time
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
import json

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bank.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db.init_app(app)
login_manager.init_app(app)

# Add this after the app initialization
app.static_folder = 'static'

# Rate limiting configuration
MAX_LOGIN_ATTEMPTS = 5
LOGIN_TIMEOUT = 15  # minutes
PASSWORD_PATTERN = re.compile(r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$')

def check_password_strength(password):
    if not PASSWORD_PATTERN.match(password):
        return False, "Password must be at least 8 characters long and contain at least one letter, one number, and one special character."
    return True, "Password is strong."

def is_rate_limited():
    if 'login_attempts' not in session:
        session['login_attempts'] = 0
        session['last_attempt'] = datetime.utcnow().timestamp()
        return False
    
    if session['login_attempts'] >= MAX_LOGIN_ATTEMPTS:
        last_attempt = datetime.fromtimestamp(session['last_attempt'])
        if datetime.utcnow() - last_attempt < timedelta(minutes=LOGIN_TIMEOUT):
            return True
        session['login_attempts'] = 0
    return False

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('customer_dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if is_rate_limited():
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Too many login attempts. Please try again later.'})
            flash('Too many login attempts. Please try again later.', 'danger')
            return render_template('login.html')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            if not user.is_active:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return jsonify({'success': False, 'message': 'Your account has been deactivated. Please contact support.'})
                flash('Your account has been deactivated. Please contact support.', 'danger')
                return render_template('login.html')
            
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            session['login_attempts'] = 0
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': True, 'redirect': url_for('customer_dashboard')})
            return redirect(url_for('customer_dashboard'))
        
        session['login_attempts'] = session.get('login_attempts', 0) + 1
        session['last_attempt'] = datetime.utcnow().timestamp()
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Invalid email or password'})
        flash('Invalid email or password', 'danger')
        return render_template('login.html')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('customer_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        phone = request.form.get('phone')
        cnic = request.form.get('cnic')
        address = request.form.get('address')
        
        # Get password requirements from database
        require_uppercase = Settings.get_setting('require_uppercase', 'true') == 'true'
        require_number = Settings.get_setting('require_number', 'true') == 'true'
        require_special = Settings.get_setting('require_special', 'true') == 'true'
        require_length = Settings.get_setting('require_length', 'true') == 'true'
        
        # Validate password
        if password != confirm_password:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Passwords do not match.'})
            flash('Passwords do not match.', 'danger')
            return render_template('register.html')
        
        # Check password requirements
        if require_length and len(password) < 8:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Password must be at least 8 characters long.'})
            flash('Password must be at least 8 characters long.', 'danger')
            return render_template('register.html')
        
        if require_uppercase and not re.search(r'[A-Z]', password):
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Password must contain at least one uppercase letter.'})
            flash('Password must contain at least one uppercase letter.', 'danger')
            return render_template('register.html')
        
        if require_number and not re.search(r'[0-9]', password):
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Password must contain at least one number.'})
            flash('Password must contain at least one number.', 'danger')
            return render_template('register.html')
        
        if require_special and not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Password must contain at least one special character.'})
            flash('Password must contain at least one special character.', 'danger')
            return render_template('register.html')
        
        # Check if user already exists
        if User.query.filter_by(email=email).first():
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Email already registered.'})
            flash('Email already registered.', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(username=username).first():
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Username already taken.'})
            flash('Username already taken.', 'danger')
            return render_template('register.html')
        
        # Create new user
        user = User(
            username=username,
            email=email,
            phone=phone,
            cnic=cnic,
            address=address
        )
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'redirect': url_for('login')})
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('customer_dashboard'))
        
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        
        if user:
            # Generate password reset token
            token = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
            user.reset_token = token
            user.reset_token_expiry = datetime.utcnow() + timedelta(hours=1)
            db.session.commit()
            
            # Send password reset email (implement in production)
            flash('Password reset instructions sent to your email', 'success')
            return redirect(url_for('login'))
            
        flash('Email not found', 'danger')
    return render_template('forgot_password.html')

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for('customer_dashboard'))
        
    user = User.query.filter_by(reset_token=token).first()
    
    if not user or user.reset_token_expiry < datetime.utcnow():
        flash('Invalid or expired reset token', 'danger')
        return redirect(url_for('forgot_password'))
        
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('reset_password.html')
            
        user.set_password(password)
        user.reset_token = None
        user.reset_token_expiry = None
        db.session.commit()
        
        flash('Password has been reset successfully. Please login with your new password.', 'success')
        return redirect(url_for('login'))
        
    return render_template('reset_password.html')

@app.route('/customer/dashboard')
@login_required
def customer_dashboard():
    theme = session.get('theme', 'light')
    show_flash = len(get_flashed_messages()) > 0
    
    # Get user's transactions
    transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.created_at.desc()).limit(5).all()
    
    # Get user's payment links
    payment_links = PaymentLink.query.filter_by(user_id=current_user.id).order_by(PaymentLink.created_at.desc()).limit(5).all()
    
    # Calculate monthly income and expenses
    now = datetime.utcnow()
    start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    
    monthly_transactions = Transaction.query.filter(
        Transaction.user_id == current_user.id,
        Transaction.created_at >= start_of_month
    ).all()
    
    monthly_income = sum(t.amount for t in monthly_transactions if t.amount > 0 and t.status == 'completed')
    monthly_expenses = abs(sum(t.amount for t in monthly_transactions if t.amount < 0 and t.status == 'completed'))
    
    # Calculate account balance
    balance = sum(t.amount for t in transactions if t.status == 'completed')
    
    return render_template('customer_dashboard.html',
                          user=current_user,
                          transactions=transactions,
                          payment_links=payment_links,
                          balance=balance,
                          monthly_income=monthly_income,
                          monthly_expenses=monthly_expenses,
                          theme=theme,
                          show_flash=show_flash)

@app.route('/api/user-data')
@login_required
def user_data():
    return jsonify({
        'username': current_user.username,
        'email': current_user.email,
        'phone': current_user.phone,
        'cnic': current_user.cnic,
        'address': current_user.address,
        'created_at': current_user.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        'last_login': current_user.last_login.strftime('%Y-%m-%d %H:%M:%S') if current_user.last_login else None
    })

@app.route('/admin/users')
@login_required
def admin_users():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('home'))
    
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin_users.html', users=users)

@app.route('/admin/transactions')
@login_required
def admin_transactions():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('home'))
    
    transactions = Transaction.query.order_by(Transaction.created_at.desc()).all()
    return render_template('admin_transactions.html', transactions=transactions)

@app.route('/admin/payment_links')
@login_required
def admin_payment_links():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('home'))
    
    payment_links = PaymentLink.query.order_by(PaymentLink.created_at.desc()).all()
    return render_template('admin_payment_links.html', payment_links=payment_links)

@app.route('/admin/settings')
@login_required
def admin_settings():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('home'))
    
    settings = Settings.get_all_settings()
    return render_template('admin_settings.html', settings=settings)

@app.route('/admin/logout')
@login_required
def admin_logout():
    logout_user()
    return redirect(url_for('admin_login'))

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if current_user.is_authenticated and current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
        
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email, is_admin=True).first()
        
        if user and user.check_password(password):
            login_user(user)
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': True, 'redirect': url_for('admin_dashboard')})
            return redirect(url_for('admin_dashboard'))
            
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Invalid admin credentials'})
        flash('Invalid admin credentials', 'danger')
        return redirect(url_for('admin_login'))
        
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('home'))
    
    # Get detailed statistics for dashboard
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    total_transactions = Transaction.query.count()
    total_payment_links = PaymentLink.query.count()
    
    # Get recent transactions
    recent_transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(10).all()
    
    # Get recent payment links
    recent_payment_links = PaymentLink.query.order_by(PaymentLink.created_at.desc()).limit(10).all()
    
    # Get recent users
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    
    # Calculate total transaction volume
    total_volume = db.session.query(db.func.sum(Transaction.amount)).filter(
        Transaction.status == 'completed'
    ).scalar() or 0
    
    return render_template('admin_dashboard.html',
                          total_users=total_users,
                          active_users=active_users,
                          total_transactions=total_transactions,
                          total_payment_links=total_payment_links,
                          recent_transactions=recent_transactions,
                          recent_payment_links=recent_payment_links,
                          recent_users=recent_users,
                          total_volume=total_volume)

@app.route('/customer/transactions')
@login_required
def view_transactions():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    transactions = Transaction.query.filter_by(user_id=current_user.id)\
        .order_by(Transaction.created_at.desc())\
        .paginate(page=page, per_page=per_page)
    
    return render_template('transactions.html', transactions=transactions)

@app.route('/customer/payment_links')
@login_required
def view_payment_links():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    payment_links = PaymentLink.query.filter_by(user_id=current_user.id)\
        .order_by(PaymentLink.created_at.desc())\
        .paginate(page=page, per_page=per_page)
    
    return render_template('payment_links.html', payment_links=payment_links)

@app.route('/create_transaction', methods=['GET', 'POST'])
@login_required
def create_transaction():
    if request.method == 'POST':
        amount = float(request.form.get('amount', 0))
        transaction_type = request.form.get('transaction_type', 'credit')
        description = request.form.get('description', '')
        
        # Get system settings from database
        min_transaction = float(Settings.get_setting('min_transaction', 1))
        max_transaction = float(Settings.get_setting('max_transaction', 10000))
        default_currency = Settings.get_setting('default_currency', 'USD')
        
        # Validate amount
        if amount < min_transaction:
            flash(f'Amount must be at least {min_transaction} {default_currency}.', 'danger')
            return render_template('create_transaction.html')
        
        if amount > max_transaction:
            flash(f'Amount cannot exceed {max_transaction} {default_currency}.', 'danger')
            return render_template('create_transaction.html')
        
        # Create transaction
        transaction = Transaction(
            user_id=current_user.id,
            amount=amount if transaction_type == 'credit' else -amount,
            transaction_type=transaction_type,
            description=description,
            status='completed'
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        flash('Transaction created successfully!', 'success')
        return redirect(url_for('view_transactions'))
    
    return render_template('create_transaction.html')

@app.route('/create_payment_link', methods=['GET', 'POST'])
@login_required
def create_payment_link():
    if request.method == 'POST':
        amount = float(request.form.get('amount', 0))
        description = request.form.get('description', '')
        expiry_days = int(request.form.get('expiry_days', 30))
        
        # Get system settings from database
        min_transaction = float(Settings.get_setting('min_transaction', 1))
        max_transaction = float(Settings.get_setting('max_transaction', 10000))
        default_currency = Settings.get_setting('default_currency', 'USD')
        
        # Validate amount
        if amount < min_transaction:
            flash(f'Amount must be at least {min_transaction} {default_currency}.', 'danger')
            return render_template('create_payment_link.html')
        
        if amount > max_transaction:
            flash(f'Amount cannot exceed {max_transaction} {default_currency}.', 'danger')
            return render_template('create_payment_link.html')
        
        # Create payment link
        payment_link = PaymentLink(
            user_id=current_user.id,
            amount=amount,
            description=description,
            expiry_date=datetime.utcnow() + timedelta(days=expiry_days)
        )
        db.session.add(payment_link)
        db.session.commit()
        
        flash('Payment link created successfully!', 'success')
        return redirect(url_for('view_payment_links'))
    
    return render_template('create_payment_link.html')

@app.route('/payment/<token>', methods=['GET', 'POST'])
def process_payment(token):
    theme = session.get('theme', 'light')
    show_flash = len(get_flashed_messages()) > 0
    payment_link = PaymentLink.query.filter_by(link_token=token).first()
    
    if not payment_link:
        flash('Invalid payment link', 'danger')
        return redirect(url_for('home'))
        
    if payment_link.status != 'active':
        flash('This payment link is no longer active', 'danger')
        return redirect(url_for('home'))
        
    if payment_link.expiry_date and payment_link.expiry_date < datetime.utcnow():
        payment_link.status = 'expired'
        db.session.commit()
        flash('This payment link has expired', 'danger')
        return redirect(url_for('home'))
        
    if request.method == 'POST':
        try:
            # Create transaction for the payment
            transaction = Transaction(
                user_id=payment_link.user_id,
                amount=payment_link.amount,
                transaction_type='credit',
                description=f'Payment via link: {payment_link.description}',
                status='completed'
            )
            
            # Update payment link status
            payment_link.status = 'used'
            
            db.session.add(transaction)
            db.session.commit()
            
            flash('Payment processed successfully!', 'success')
            return redirect(url_for('home'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred: {str(e)}', 'danger')
            return redirect(url_for('process_payment', token=token))
    
    return render_template('process_payment.html', payment_link=payment_link, theme=theme, show_flash=show_flash)

# Add this route to handle dark mode preference
@app.route('/api/theme', methods=['POST'])
def set_theme():
    data = request.get_json()
    theme = data.get('theme', 'light')
    session['theme'] = theme
    return jsonify({'status': 'success'})

@app.route('/admin/settings/security', methods=['POST'])
@login_required
def admin_security_settings():
    if not current_user.is_admin:
        return jsonify({'success': False, 'message': 'Access denied. Admin privileges required.'})
    
    try:
        max_login_attempts = int(request.form.get('max_login_attempts', 5))
        login_timeout = int(request.form.get('login_timeout', 15))
        require_uppercase = request.form.get('require_uppercase') == 'on'
        require_number = request.form.get('require_number') == 'on'
        require_special = request.form.get('require_special') == 'on'
        require_length = request.form.get('require_length') == 'on'
        
        # Update security settings in database
        Settings.set_setting('max_login_attempts', str(max_login_attempts))
        Settings.set_setting('login_timeout', str(login_timeout))
        Settings.set_setting('require_uppercase', str(require_uppercase).lower())
        Settings.set_setting('require_number', str(require_number).lower())
        Settings.set_setting('require_special', str(require_special).lower())
        Settings.set_setting('require_length', str(require_length).lower())
        
        return jsonify({'success': True, 'message': 'Security settings updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error updating security settings: {str(e)}'})

@app.route('/admin/settings/system', methods=['POST'])
@login_required
def admin_system_settings():
    if not current_user.is_admin:
        return jsonify({'success': False, 'message': 'Access denied. Admin privileges required.'})
    
    try:
        default_currency = request.form.get('default_currency', 'USD')
        payment_link_expiry = int(request.form.get('payment_link_expiry', 30))
        min_transaction = float(request.form.get('min_transaction', 1))
        max_transaction = float(request.form.get('max_transaction', 10000))
        maintenance_mode = request.form.get('maintenance_mode') == 'on'
        
        # Update system settings in database
        Settings.set_setting('default_currency', default_currency)
        Settings.set_setting('payment_link_expiry', str(payment_link_expiry))
        Settings.set_setting('min_transaction', str(min_transaction))
        Settings.set_setting('max_transaction', str(max_transaction))
        Settings.set_setting('maintenance_mode', str(maintenance_mode).lower())
        
        return jsonify({'success': True, 'message': 'System settings updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error updating system settings: {str(e)}'})

@app.route('/admin/settings/backup', methods=['POST'])
@login_required
def admin_backup_settings():
    if not current_user.is_admin:
        return jsonify({'success': False, 'message': 'Access denied. Admin privileges required.'})
    
    try:
        auto_backup = request.form.get('auto_backup') == 'on'
        backup_frequency = request.form.get('backup_frequency', 'daily')
        backup_retention = int(request.form.get('backup_retention', 30))
        
        # Update backup settings in database
        Settings.set_setting('auto_backup', str(auto_backup).lower())
        Settings.set_setting('backup_frequency', backup_frequency)
        Settings.set_setting('backup_retention', str(backup_retention))
        
        return jsonify({'success': True, 'message': 'Backup settings updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error updating backup settings: {str(e)}'})

@app.route('/admin/settings/backup/create', methods=['POST'])
@login_required
def admin_create_backup():
    if not current_user.is_admin:
        return jsonify({'success': False, 'message': 'Access denied. Admin privileges required.'})
    
    try:
        # Implement backup creation logic
        # This is a placeholder - implement actual backup functionality
        # For now, we'll just log that a backup was requested
        print(f"Backup requested by admin user {current_user.username} at {datetime.now()}")
        
        return jsonify({'success': True, 'message': 'Backup created successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error creating backup: {str(e)}'})

@app.route('/admin/settings/email', methods=['POST'])
@login_required
def admin_email_settings():
    if not current_user.is_admin:
        return jsonify({'success': False, 'message': 'Access denied. Admin privileges required.'})
    
    try:
        smtp_server = request.form.get('smtp_server', '')
        smtp_port = int(request.form.get('smtp_port', 587))
        smtp_username = request.form.get('smtp_username', '')
        smtp_password = request.form.get('smtp_password', '')
        from_email = request.form.get('from_email', '')
        
        # Update email settings in database
        Settings.set_setting('smtp_server', smtp_server)
        Settings.set_setting('smtp_port', str(smtp_port))
        Settings.set_setting('smtp_username', smtp_username)
        Settings.set_setting('smtp_password', smtp_password)
        Settings.set_setting('from_email', from_email)
        
        return jsonify({'success': True, 'message': 'Email settings updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error updating email settings: {str(e)}'})

@app.route('/admin/settings/email/test', methods=['POST'])
@login_required
def admin_test_email():
    if not current_user.is_admin:
        return jsonify({'success': False, 'message': 'Access denied. Admin privileges required.'})
    
    try:
        # Implement test email sending logic
        # This is a placeholder - implement actual email sending functionality
        # For now, we'll just log that a test email was requested
        print(f"Test email requested by admin user {current_user.username} at {datetime.now()}")
        
        return jsonify({'success': True, 'message': 'Test email sent successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error sending test email: {str(e)}'})

@app.route('/api/admin-data')
@login_required
def admin_data():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    return jsonify({
        'username': current_user.username,
        'email': current_user.email
    })

@app.route('/api/admin-user-data/<int:user_id>')
@login_required
def admin_user_data(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    user = User.query.get_or_404(user_id)
    transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).limit(5).all()
    return jsonify({
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'phone': user.phone,
        'cnic': user.cnic,
        'address': user.address,
        'is_active': user.is_active,
        'created_at': user.created_at.isoformat(),
        'transactions': [{
            'id': t.id,
            'amount': t.amount,
            'transaction_type': t.transaction_type,
            'status': t.status,
            'created_at': t.created_at.isoformat()
        } for t in transactions]
    })

@app.route('/api/transaction-data/<int:transaction_id>')
@login_required
def transaction_data(transaction_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    transaction = Transaction.query.get_or_404(transaction_id)
    return jsonify({
        'id': transaction.id,
        'amount': transaction.amount,
        'transaction_type': transaction.transaction_type,
        'status': transaction.status,
        'created_at': transaction.created_at.isoformat(),
        'user': {
            'username': transaction.user.username,
            'email': transaction.user.email,
            'phone': transaction.user.phone,
            'cnic': transaction.user.cnic
        },
        'fraud_probability': transaction.fraud_probability,
        'risk_score': transaction.risk_score,
        'location': transaction.location,
        'device': transaction.device,
        'history': [{
            'timestamp': h.timestamp.isoformat(),
            'action': h.action,
            'status': h.status,
            'notes': h.notes
        } for h in transaction.history]
    })

@app.route('/api/payment-links', methods=['GET', 'POST'])
@login_required
def payment_links_api():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if request.method == 'POST':
        data = request.get_json()
        link = PaymentLink(
            amount=data['amount'],
            customer_email=data.get('customer_email'),
            expires_at=datetime.fromisoformat(data['expires_at']),
            exempt_from_fraud=data.get('exempt_from_fraud', False)
        )
        db.session.add(link)
        db.session.commit()
        return jsonify({'success': True, 'link': link.link})
    
    links = PaymentLink.query.order_by(PaymentLink.created_at.desc()).all()
    return jsonify([{
        'id': link.id,
        'link': link.link,
        'amount': link.amount,
        'customer_email': link.customer_email,
        'created_at': link.created_at.isoformat(),
        'expires_at': link.expires_at.isoformat(),
        'status': link.status
    } for link in links])

@app.route('/api/payment-links/<int:link_id>')
@login_required
def payment_link_data(link_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    link = PaymentLink.query.get_or_404(link_id)
    return jsonify({
        'id': link.id,
        'link': link.link,
        'amount': link.amount,
        'customer_email': link.customer_email,
        'created_at': link.created_at.isoformat(),
        'expires_at': link.expires_at.isoformat(),
        'status': link.status,
        'customer_ip': link.customer_ip,
        'customer_location': link.customer_location,
        'customer_device': link.customer_device,
        'payment_attempts': [{
            'timestamp': attempt.timestamp.isoformat(),
            'status': attempt.status,
            'ip_address': attempt.ip_address,
            'device': attempt.device
        } for attempt in link.payment_attempts]
    })

@app.route('/api/payment-links/<int:link_id>/deactivate', methods=['POST'])
@login_required
def deactivate_payment_link(link_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    link = PaymentLink.query.get_or_404(link_id)
    link.status = 'expired'
    db.session.commit()
    return jsonify({'success': True})

@app.route('/api/settings', methods=['GET', 'POST'])
@login_required
def settings_api():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if request.method == 'POST':
        data = request.get_json()
        for key, value in data.items():
            Settings.set_setting(key, str(value))
        return jsonify({'success': True})
    
    settings = Settings.get_all_settings()
    return jsonify({
        'enable_fraud_detection': settings.get('enable_fraud_detection', 'false'),
        'fraud_threshold': settings.get('fraud_threshold', '0.7'),
        'enable_ip_blocking': settings.get('enable_ip_blocking', 'true'),
        'max_failed_attempts': settings.get('max_failed_attempts', '5'),
        'min_transaction_amount': settings.get('min_transaction_amount', '1'),
        'max_transaction_amount': settings.get('max_transaction_amount', '10000'),
        'require_approval': settings.get('require_approval', 'false'),
        'approval_threshold': settings.get('approval_threshold', '1000'),
        'link_expiry_hours': settings.get('link_expiry_hours', '24'),
        'allow_multiple_payments': settings.get('allow_multiple_payments', 'true'),
        'require_customer_email': settings.get('require_customer_email', 'true'),
        'email_notifications': settings.get('email_notifications', 'true'),
        'sms_notifications': settings.get('sms_notifications', 'false'),
        'admin_email': settings.get('admin_email', '')
    })

@app.route('/api/admin/activities')
@login_required
def admin_activities():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    # Get recent user activities
    recent_logins = User.query.filter(User.last_login.isnot(None)).order_by(User.last_login.desc()).limit(5).all()
    recent_transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(5).all()
    
    return jsonify({
        'recent_logins': [{
            'username': user.username,
            'email': user.email,
            'last_login': user.last_login.isoformat() if user.last_login else None
        } for user in recent_logins],
        'recent_transactions': [{
            'id': t.id,
            'user': t.user.username,
            'amount': t.amount,
            'status': t.status,
            'created_at': t.created_at.isoformat()
        } for t in recent_transactions]
    })

@app.route('/api/admin/transactions/<int:transaction_id>/action', methods=['POST'])
@login_required
def admin_transaction_action(transaction_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    transaction = Transaction.query.get_or_404(transaction_id)
    action = request.json.get('action')
    
    if action == 'approve':
        transaction.status = 'approved'
        # Add to transaction history
        history = TransactionHistory(
            transaction=transaction,
            action='admin_approval',
            status='approved',
            notes='Approved by admin'
        )
        db.session.add(history)
    elif action == 'decline':
        transaction.status = 'declined'
        # Add to transaction history
        history = TransactionHistory(
            transaction=transaction,
            action='admin_decline',
            status='declined',
            notes='Declined by admin'
        )
        db.session.add(history)
    elif action == 'flag':
        transaction.status = 'flagged'
        # Add to transaction history
        history = TransactionHistory(
            transaction=transaction,
            action='admin_flag',
            status='flagged',
            notes='Flagged by admin for review'
        )
        db.session.add(history)
    else:
        return jsonify({'error': 'Invalid action'}), 400
    
    db.session.commit()
    return jsonify({'success': True, 'status': transaction.status})

@app.route('/api/admin/users/<int:user_id>/status', methods=['POST'])
@login_required
def admin_user_status(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    user = User.query.get_or_404(user_id)
    action = request.json.get('action')
    
    if action == 'activate':
        user.is_active = True
    elif action == 'deactivate':
        user.is_active = False
    else:
        return jsonify({'error': 'Invalid action'}), 400
    
    db.session.commit()
    return jsonify({'success': True, 'is_active': user.is_active})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Initialize default settings
        Settings.initialize_default_settings()
       app.run(debug=True)