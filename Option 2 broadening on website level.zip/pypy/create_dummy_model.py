from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib
import os

# Create a dummy model
model = RandomForestClassifier()

# Create a dummy scaler
scaler = StandardScaler()

# Create models directory if it doesn't exist
os.makedirs('models', exist_ok=True)

# Save the model and scaler
joblib.dump(model, 'models/fraud_detection_model.pkl')
joblib.dump(scaler, 'models/scaler.pkl') 