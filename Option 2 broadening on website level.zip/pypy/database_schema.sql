-- Create the database
CREATE DATABASE IF NOT EXISTS fraud_detection;
USE fraud_detection;

-- Customers table
CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    cnic VARCHAR(20) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    amount DECIMAL(10, 2) NOT NULL,
    location VARCHAR(100) NOT NULL,
    merchant VARCHAR(100) NOT NULL,
    card_number VARCHAR(20) NOT NULL,
    ip_address VARCHAR(50) NOT NULL,
    mac_address VARCHAR(50) NOT NULL,
    is_fraudulent BOOLEAN DEFAULT FALSE,
    fraud_probability DECIMAL(5, 4),
    status VARCHAR(20) DEFAULT 'pending',
    decision VARCHAR(20) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Fraudulent customers table
CREATE TABLE IF NOT EXISTS fraudulent_customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    reason TEXT NOT NULL,
    status ENUM('Flagged', 'Under Investigation', 'Cleared', 'Blocked') DEFAULT 'Flagged',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Payment links table
CREATE TABLE IF NOT EXISTS payment_links (
    link_id VARCHAR(32) PRIMARY KEY,
    amount DECIMAL(10, 2) NOT NULL,
    country VARCHAR(50) NOT NULL,
    exempt_rules BOOLEAN DEFAULT FALSE,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (created_by) REFERENCES customers(customer_id)
);

-- Admins table
CREATE TABLE IF NOT EXISTS admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin
INSERT INTO admins (username, password_hash, email) 
VALUES ('admin', SHA2('admin123', 256), 'admin@cbzbank.com');

-- Create table for transaction risk factors
CREATE TABLE transaction_risk_factors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT NOT NULL,
    risk_factor VARCHAR(50) NOT NULL,
    value BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id) ON DELETE CASCADE,
    UNIQUE KEY unique_risk_factor (transaction_id, risk_factor)
);

-- Create indexes for better query performance
CREATE INDEX idx_transactions_fraud ON transactions(is_fraudulent, fraud_probability);
CREATE INDEX idx_transactions_created_at ON transactions(created_at);
CREATE INDEX idx_transactions_location ON transactions(location);
CREATE INDEX idx_transaction_risk_factors_factor ON transaction_risk_factors(risk_factor); 