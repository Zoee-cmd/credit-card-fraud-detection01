import joblib
import numpy as np
import pandas as pd
from datetime import datetime
import mysql.connector
from typing import Dict, Any, Tuple

class FraudDetector:
    def __init__(self, model_path='models/fraud_detection_model.pkl', scaler_path='models/scaler.pkl'):
        """Initialize the fraud detector with a trained model and scaler."""
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)
        self.db_connection = None
    
    def connect_to_db(self):
        """Establish database connection."""
        if not self.db_connection or not self.db_connection.is_connected():
            self.db_connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="fraud_detection"
            )
        return self.db_connection
    
    def get_customer_history(self, customer_id: int) -> pd.DataFrame:
        """Get transaction history for a customer."""
        conn = self.connect_to_db()
        cursor = conn.cursor(dictionary=True)
        
        query = """
        SELECT 
            t.amount, 
            t.location, 
            t.merchant, 
            t.card_number, 
            t.ip_address, 
            t.mac_address,
            t.created_at,
            c.email,
            c.cnic
        FROM transactions t
        JOIN customers c ON t.customer_id = c.customer_id
        WHERE t.customer_id = %s
        ORDER BY t.created_at DESC
        LIMIT 100
        """
        
        cursor.execute(query, (customer_id,))
        data = cursor.fetchall()
        cursor.close()
        
        return pd.DataFrame(data)
    
    def engineer_features(self, transaction_data: Dict[str, Any], customer_history: pd.DataFrame) -> np.ndarray:
        """Engineer features for a single transaction."""
        # Create a DataFrame with the current transaction
        current_transaction = pd.DataFrame([transaction_data])
        
        # Combine with customer history
        df = pd.concat([current_transaction, customer_history], ignore_index=True)
        
        # Extract time features
        df['created_at'] = pd.to_datetime(df['created_at'])
        df['hour'] = df['created_at'].dt.hour
        df['day_of_week'] = df['created_at'].dt.dayofweek
        df['month'] = df['created_at'].dt.month
        
        # Extract email domain
        df['email_domain'] = df['email'].apply(lambda x: x.split('@')[1] if '@' in x else 'unknown')
        
        # Count transactions per customer
        customer_counts = df.groupby('cnic').size().reset_index(name='customer_transaction_count')
        df = df.merge(customer_counts, on='cnic', how='left')
        
        # Count transactions per card
        card_counts = df.groupby('card_number').size().reset_index(name='card_transaction_count')
        df = df.merge(card_counts, on='card_number', how='left')
        
        # Count transactions per IP
        ip_counts = df.groupby('ip_address').size().reset_index(name='ip_transaction_count')
        df = df.merge(ip_counts, on='ip_address', how='left')
        
        # Count transactions per MAC
        mac_counts = df.groupby('mac_address').size().reset_index(name='mac_transaction_count')
        df = df.merge(mac_counts, on='mac_address', how='left')
        
        # Count transactions per email
        email_counts = df.groupby('email').size().reset_index(name='email_transaction_count')
        df = df.merge(email_counts, on='email', how='left')
        
        # Count transactions per email domain
        domain_counts = df.groupby('email_domain').size().reset_index(name='domain_transaction_count')
        df = df.merge(domain_counts, on='email_domain', how='left')
        
        # Create categorical features
        df['location_encoded'] = pd.Categorical(df['location']).codes
        df['merchant_encoded'] = pd.Categorical(df['merchant']).codes
        df['email_domain_encoded'] = pd.Categorical(df['email_domain']).codes
        
        # Select features for the current transaction
        feature_columns = [
            'amount', 'hour', 'day_of_week', 'month',
            'location_encoded', 'merchant_encoded', 'email_domain_encoded',
            'customer_transaction_count', 'card_transaction_count',
            'ip_transaction_count', 'mac_transaction_count',
            'email_transaction_count', 'domain_transaction_count'
        ]
        
        # Get features for the current transaction
        features = df[feature_columns].iloc[0].values.reshape(1, -1)
        
        # Scale features
        features_scaled = self.scaler.transform(features)
        
        return features_scaled
    
    def detect_fraud(self, transaction_data: Dict[str, Any], customer_id: int) -> Tuple[bool, float, Dict[str, Any]]:
        """
        Detect if a transaction is fraudulent.
        
        Args:
            transaction_data: Dictionary containing transaction details
            customer_id: ID of the customer making the transaction
            
        Returns:
            Tuple containing:
            - Boolean indicating if transaction is fraudulent
            - Probability of fraud
            - Dictionary containing additional risk factors
        """
        # Get customer transaction history
        customer_history = self.get_customer_history(customer_id)
        
        # Engineer features
        features = self.engineer_features(transaction_data, customer_history)
        
        # Get prediction and probability
        is_fraudulent = bool(self.model.predict(features)[0])
        fraud_probability = float(self.model.predict_proba(features)[0, 1])
        
        # Calculate additional risk factors
        risk_factors = self._calculate_risk_factors(transaction_data, customer_history)
        
        return is_fraudulent, fraud_probability, risk_factors
    
    def _calculate_risk_factors(self, transaction_data: Dict[str, Any], customer_history: pd.DataFrame) -> Dict[str, Any]:
        """Calculate additional risk factors for the transaction."""
        risk_factors = {
            'high_amount': False,
            'unusual_location': False,
            'unusual_merchant': False,
            'multiple_cards': False,
            'multiple_ips': False,
            'multiple_macs': False,
            'unusual_email_domain': False,
            'high_frequency': False
        }
        
        # Check for high amount
        if float(transaction_data['amount']) > 5000:
            risk_factors['high_amount'] = True
        
        # Check for unusual location
        if not customer_history.empty:
            usual_locations = customer_history['location'].value_counts()
            if transaction_data['location'] not in usual_locations.index[:3]:
                risk_factors['unusual_location'] = True
        
        # Check for unusual merchant
        if not customer_history.empty:
            usual_merchants = customer_history['merchant'].value_counts()
            if transaction_data['merchant'] not in usual_merchants.index[:3]:
                risk_factors['unusual_merchant'] = True
        
        # Check for multiple cards
        unique_cards = customer_history['card_number'].nunique()
        if unique_cards > 2:
            risk_factors['multiple_cards'] = True
        
        # Check for multiple IPs
        unique_ips = customer_history['ip_address'].nunique()
        if unique_ips > 3:
            risk_factors['multiple_ips'] = True
        
        # Check for multiple MACs
        unique_macs = customer_history['mac_address'].nunique()
        if unique_macs > 2:
            risk_factors['multiple_macs'] = True
        
        # Check for unusual email domain
        if not customer_history.empty:
            usual_domains = customer_history['email'].apply(lambda x: x.split('@')[1]).value_counts()
            current_domain = transaction_data['email'].split('@')[1]
            if current_domain not in usual_domains.index[:2]:
                risk_factors['unusual_email_domain'] = True
        
        # Check for high transaction frequency
        if not customer_history.empty:
            recent_transactions = customer_history[
                customer_history['created_at'] > pd.Timestamp.now() - pd.Timedelta(hours=24)
            ]
            if len(recent_transactions) > 10:
                risk_factors['high_frequency'] = True
        
        return risk_factors
    
    def __del__(self):
        """Close database connection when object is destroyed."""
        if self.db_connection and self.db_connection.is_connected():
            self.db_connection.close() 