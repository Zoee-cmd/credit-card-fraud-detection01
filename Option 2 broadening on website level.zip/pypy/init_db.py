from app import app, db
from models.user import User
from models.transaction import Transaction
from models.payment_link import PaymentLink
from models.settings import Settings

with app.app_context():
    # Drop all tables and recreate them
    db.drop_all()
    db.create_all()
    
    # Create admin user
    admin_email = 'admin@cbzbank.com'
    admin = User(
        username='admin',
        email=admin_email,
        is_admin=True,
        is_active=True
    )
    admin.set_password('Admin@123')
    db.session.add(admin)
    
    # Initialize default settings
    default_settings = [
        Settings(key='require_uppercase', value='true'),
        Settings(key='require_number', value='true'),
        Settings(key='require_special', value='true'),
        Settings(key='require_length', value='true'),
        Settings(key='max_login_attempts', value='5'),
        Settings(key='login_timeout', value='15')
    ]
    
    for setting in default_settings:
        db.session.add(setting)
    
    db.session.commit()
    print("Admin user created successfully!")
    print("Default settings initialized!")
    print("Database initialized successfully!") 