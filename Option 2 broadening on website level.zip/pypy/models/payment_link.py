from datetime import datetime
from extensions import db

class PaymentLink(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200))
    link_token = db.Column(db.String(100), unique=True, nullable=False)
    status = db.Column(db.String(20), default='active')  # 'active', 'used', 'expired'
    expiry_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<PaymentLink {self.id}: {self.amount}>' 