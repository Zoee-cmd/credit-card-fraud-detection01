from extensions import db
from datetime import datetime

class Settings(db.Model):
    __tablename__ = 'settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=True)
    description = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_setting(cls, key, default=None):
        """Get a setting value by key"""
        setting = cls.query.filter_by(key=key).first()
        return setting.value if setting else default
    
    @classmethod
    def set_setting(cls, key, value, description=None):
        """Set a setting value by key"""
        setting = cls.query.filter_by(key=key).first()
        if setting:
            setting.value = value
            if description:
                setting.description = description
        else:
            setting = cls(key=key, value=value, description=description)
            db.session.add(setting)
        
        db.session.commit()
        return setting
    
    @classmethod
    def get_all_settings(cls):
        """Get all settings as a dictionary"""
        settings = cls.query.all()
        return {setting.key: setting.value for setting in settings}
    
    @classmethod
    def initialize_default_settings(cls):
        """Initialize default settings if they don't exist"""
        default_settings = {
            # Security Settings
            'max_login_attempts': '5',
            'login_timeout': '15',
            'require_uppercase': 'true',
            'require_number': 'true',
            'require_special': 'true',
            'require_length': 'true',
            'enable_ip_blocking': 'true',
            'max_failed_attempts': '5',
            
            # System Settings
            'default_currency': 'USD',
            'payment_link_expiry': '30',
            'min_transaction': '1',
            'max_transaction': '10000',
            'maintenance_mode': 'false',
            'min_transaction_amount': '1',
            'max_transaction_amount': '10000',
            'require_approval': 'false',
            'approval_threshold': '1000',
            'link_expiry_hours': '24',
            'allow_multiple_payments': 'true',
            'require_customer_email': 'true',
            
            # Fraud Detection Settings
            'enable_fraud_detection': 'false',
            'fraud_threshold': '0.7',
            
            # Notification Settings
            'email_notifications': 'true',
            'sms_notifications': 'false',
            'admin_email': '',
            
            # Email Settings
            'smtp_server': '',
            'smtp_port': '587',
            'smtp_username': '',
            'smtp_password': '',
            'from_email': '',
            
            # Backup Settings
            'auto_backup': 'true',
            'backup_frequency': 'daily',
            'backup_retention': '30'
        }
        
        for key, value in default_settings.items():
            if not cls.query.filter_by(key=key).first():
                cls.set_setting(key, value) 