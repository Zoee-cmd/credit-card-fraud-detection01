import os
import subprocess
import sys
import time

def check_mysql_installed():
    """Check if MySQL is installed and running"""
    try:
        # Try to connect to MySQL
        import mysql.connector
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password=""
        )
        conn.close()
        return True
    except Exception as e:
        print(f"Error connecting to MySQL: {e}")
        return False

def setup_database():
    """Set up the database using the SQL script"""
    try:
        # Connect to MySQL
        import mysql.connector
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password=""
        )
        cursor = conn.cursor()
        
        # Read the SQL script
        with open('database_schema.sql', 'r') as file:
            sql_script = file.read()
        
        # Execute the SQL script
        for statement in sql_script.split(';'):
            if statement.strip():
                cursor.execute(statement)
        
        conn.commit()
        cursor.close()
        conn.close()
        print("Database setup completed successfully!")
        return True
    except Exception as e:
        print(f"Error setting up database: {e}")
        return False

def create_dummy_model():
    """Create a dummy model for testing"""
    try:
        # Run the create_dummy_model.py script
        subprocess.run([sys.executable, 'create_dummy_model.py'], check=True)
        print("Dummy model created successfully!")
        return True
    except Exception as e:
        print(f"Error creating dummy model: {e}")
        return False

def run_application():
    """Run the Flask application"""
    try:
        print("Starting the Flask application...")
        subprocess.run([sys.executable, 'app.py'], check=True)
    except KeyboardInterrupt:
        print("\nApplication stopped by user.")
    except Exception as e:
        print(f"Error running application: {e}")

def main():
    print("=== CBZ Bank Application Setup ===")
    
    # Check if MySQL is installed
    if not check_mysql_installed():
        print("MySQL is not installed or not running. Please install MySQL and try again.")
        return
    
    # Set up the database
    if not setup_database():
        print("Failed to set up the database. Please check the error message above.")
        return
    
    # Create dummy model
    if not create_dummy_model():
        print("Failed to create dummy model. Please check the error message above.")
        return
    
    # Run the application
    run_application()

if __name__ == "__main__":
    main() 