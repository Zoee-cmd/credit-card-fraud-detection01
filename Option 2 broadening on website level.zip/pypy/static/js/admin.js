document.addEventListener('DOMContentLoaded', function() {
    // Load admin data
    loadAdminData();
    
    // Load initial data
    loadTransactions();
    loadCustomers();
    
    // Set up event listeners
    setupEventListeners();
});

function loadAdminData() {
    fetch('/api/admin-data')
        .then(response => response.json())
        .then(data => {
            document.getElementById('admin-name').textContent = data.username;
            document.getElementById('admin-email').textContent = data.email;
            document.getElementById('admin-avatar').textContent = data.username.charAt(0).toUpperCase();
        })
        .catch(error => console.error('Error loading admin data:', error));
}

function loadTransactions() {
    fetch('/api/transactions')
        .then(response => response.json())
        .then(transactions => {
            const tbody = document.querySelector('#transactions-tab table tbody');
            tbody.innerHTML = '';
            
            transactions.forEach(transaction => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>#${transaction.id}</td>
                    <td>${transaction.customer}</td>
                    <td>$${transaction.amount.toFixed(2)}</td>
                    <td>${transaction.location}</td>
                    <td>${transaction.merchant}</td>
                    <td>${transaction.date}</td>
                    <td><span class="status-badge status-${transaction.status.toLowerCase()}">${transaction.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary action-btn" onclick="viewTransaction(${transaction.id})">View</button>
                        ${transaction.status === 'FLAGGED' ? `
                            <button class="btn btn-sm btn-outline-success action-btn" onclick="updateTransactionStatus(${transaction.id}, 'APPROVED')">Approve</button>
                            <button class="btn btn-sm btn-outline-danger action-btn" onclick="updateTransactionStatus(${transaction.id}, 'DECLINED')">Decline</button>
                        ` : ''}
                    </td>
                `;
                tbody.appendChild(tr);
            });
        })
        .catch(error => console.error('Error loading transactions:', error));
}

function loadCustomers() {
    fetch('/api/customers')
        .then(response => response.json())
        .then(customers => {
            const tbody = document.querySelector('#customer-records-tab table tbody');
            tbody.innerHTML = '';
            
            customers.forEach(customer => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>#${customer.id}</td>
                    <td>${customer.name}</td>
                    <td>${customer.email}</td>
                    <td>${customer.phone}</td>
                    <td>${customer.cnic}</td>
                    <td><span class="status-badge status-${customer.status.toLowerCase()}">${customer.status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary action-btn" onclick="viewCustomer(${customer.id})">View</button>
                        <button class="btn btn-sm btn-outline-warning action-btn" onclick="toggleCustomerFlag(${customer.id})">${customer.status === 'FLAGGED' ? 'Unflag' : 'Flag'}</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        })
        .catch(error => console.error('Error loading customers:', error));
}

function viewTransaction(transactionId) {
    fetch(`/api/transaction/${transactionId}`)
        .then(response => response.json())
        .then(transaction => {
            // Populate modal with transaction details
            document.getElementById('transactionId').textContent = `#${transaction.id}`;
            document.getElementById('transactionAmount').textContent = `$${transaction.amount.toFixed(2)}`;
            document.getElementById('transactionMerchant').textContent = transaction.merchant;
            document.getElementById('transactionDate').textContent = transaction.date;
            document.getElementById('transactionStatus').innerHTML = `<span class="status-badge status-${transaction.status.toLowerCase()}">${transaction.status}</span>`;
            
            document.getElementById('transactionCustomerName').textContent = transaction.customer.name;
            document.getElementById('transactionCustomerEmail').textContent = transaction.customer.email;
            document.getElementById('transactionCustomerPhone').textContent = transaction.customer.phone;
            document.getElementById('transactionCustomerCNIC').textContent = transaction.customer.cnic;
            
            document.getElementById('transactionIP').textContent = transaction.device_info.split('|')[0];
            document.getElementById('transactionLocation').textContent = transaction.location;
            document.getElementById('transactionDevice').textContent = transaction.device_info.split('|')[1];
            
            document.getElementById('transactionFraudProb').textContent = (transaction.risk_score * 100).toFixed(1);
            
            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('transactionDetailsModal'));
            modal.show();
        })
        .catch(error => console.error('Error loading transaction details:', error));
}

function updateTransactionStatus(transactionId, status) {
    fetch(`/api/transaction/${transactionId}/status`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadTransactions();
            const modal = bootstrap.Modal.getInstance(document.getElementById('transactionDetailsModal'));
            modal.hide();
        }
    })
    .catch(error => console.error('Error updating transaction status:', error));
}

function setupEventListeners() {
    // Credit card testing form
    const creditCardTestForm = document.getElementById('creditCardTestForm');
    if (creditCardTestForm) {
        creditCardTestForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Implement credit card testing logic
            const testResults = document.getElementById('testResults');
            const testStatus = document.getElementById('testStatus');
            const riskFactors = document.getElementById('riskFactors');
            
            // Simulate testing
            const isApproved = Math.random() > 0.3;
            const fraudProbability = Math.random();
            const detectedRisks = [];
            
            if (fraudProbability > 0.7) {
                detectedRisks.push('High risk transaction pattern detected');
            }
            if (Math.random() > 0.5) {
                detectedRisks.push('Unusual location detected');
            }
            
            testResults.style.display = 'block';
            testStatus.innerHTML = `<strong>Status:</strong> <span class="text-${isApproved ? 'success' : 'danger'}">Transaction ${isApproved ? 'Approved' : 'Declined'}</span>`;
            testStatus.innerHTML += `<br><strong>Fraud Probability:</strong> ${(fraudProbability * 100).toFixed(1)}%`;
            
            if (detectedRisks.length > 0) {
                let risksHtml = '<strong>Detected Risks:</strong><ul>';
                detectedRisks.forEach(risk => {
                    risksHtml += `<li>${risk}</li>`;
                });
                risksHtml += '</ul>';
                riskFactors.innerHTML = risksHtml;
            } else {
                riskFactors.innerHTML = '<strong>Detected Risks:</strong> None';
            }
        });
    }
    
    // Payment link creation
    const createLinkBtn = document.getElementById('createLinkBtn');
    if (createLinkBtn) {
        createLinkBtn.addEventListener('click', function() {
            const amount = document.getElementById('linkAmount').value;
            const country = document.getElementById('linkCountry').value;
            const email = document.getElementById('linkEmail').value;
            
            if (!amount || !country || !email) {
                alert('Please fill in all required fields');
                return;
            }
            
            // In a real app, this would send data to the server
            alert(`Payment link created for $${amount} to ${email} in ${country}`);
            
            const modal = bootstrap.Modal.getInstance(document.getElementById('createPaymentLinkModal'));
            modal.hide();
        });
    }
} 