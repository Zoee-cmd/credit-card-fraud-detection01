document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetSection = this.getAttribute('data-section');
            
            // Update active states
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Show/hide sections
            sections.forEach(section => {
                if (section.id === `${targetSection}-section`) {
                    section.classList.remove('d-none');
                    section.classList.add('active');
                } else {
                    section.classList.add('d-none');
                    section.classList.remove('active');
                }
            });
        });
    });

    // Load customers
    async function loadCustomers() {
        try {
            const response = await fetch('/admin/customers');
            const customers = await response.json();
            
            const tbody = document.getElementById('customersTableBody');
            tbody.innerHTML = customers.map(customer => `
                <tr>
                    <td>${customer.name}</td>
                    <td>${customer.email}</td>
                    <td>${customer.phone}</td>
                    <td>${customer.address}</td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="viewCustomerDetails(${customer.id})">
                            View Details
                        </button>
                    </td>
                </tr>
            `).join('');
        } catch (error) {
            console.error('Error loading customers:', error);
        }
    }

    // Load fraudulent customers
    async function loadFraudulentCustomers() {
        try {
            const response = await fetch('/admin/fraudulent');
            const fraudulent = await response.json();
            
            const tbody = document.getElementById('fraudulentTableBody');
            tbody.innerHTML = fraudulent.map(customer => `
                <tr>
                    <td>${customer.id}</td>
                    <td>${customer.name}</td>
                    <td>${customer.email}</td>
                    <td>${customer.status}</td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick="updateStatus(${customer.id})">
                            Update Status
                        </button>
                    </td>
                </tr>
            `).join('');
        } catch (error) {
            console.error('Error loading fraudulent customers:', error);
        }
    }

    // Payment link generation
    const paymentLinkForm = document.getElementById('paymentLinkForm');
    paymentLinkForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = {
            amount: document.getElementById('amount').value,
            country: document.getElementById('country').value,
            exemptRules: document.getElementById('exemptRules').checked
        };

        try {
            const response = await fetch('/admin/generate-payment-link', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (response.ok) {
                alert(`Payment link generated: ${window.location.origin}${data.payment_link}\nExpires: ${new Date(data.expiry).toLocaleString()}`);
            } else {
                alert(data.error || 'Failed to generate payment link');
            }
        } catch (error) {
            alert('An error occurred while generating the payment link');
        }
    });

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        window.location.href = '/admin/login';
    });

    // Initial load
    loadCustomers();
    loadFraudulentCustomers();
});

// Customer details modal
function viewCustomerDetails(customerId) {
    // In production, fetch customer details from the server
    const customerDetailsModal = new bootstrap.Modal(document.getElementById('customerDetailsModal'));
    customerDetailsModal.show();
}

// Update fraudulent customer status
function updateStatus(customerId) {
    // In production, implement status update logic
    alert('Status update functionality to be implemented');
} 