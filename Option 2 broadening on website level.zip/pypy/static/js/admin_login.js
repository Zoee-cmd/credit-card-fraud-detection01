document.addEventListener('DOMContentLoaded', function() {
    const adminLoginForm = document.getElementById('adminLoginForm');
    
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            try {
                const response = await fetch('/admin/login', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    window.location.href = data.redirect;
                } else {
                    // Create or update error alert
                    let alertDiv = document.querySelector('.alert-danger');
                    if (!alertDiv) {
                        alertDiv = document.createElement('div');
                        alertDiv.className = 'alert alert-danger';
                        adminLoginForm.insertBefore(alertDiv, adminLoginForm.firstChild);
                    }
                    alertDiv.textContent = data.message;
                }
            } catch (error) {
                console.error('An error occurred during login:', error);
                alert('An error occurred during login. Please try again.');
            }
        });
    }
}); 