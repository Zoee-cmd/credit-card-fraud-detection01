document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    let fraudTrendsChart = null;
    let riskFactorsChart = null;
    
    // Load initial data
    loadDashboardData();
    
    // Set up refresh button
    document.getElementById('refreshData').addEventListener('click', function(e) {
        e.preventDefault();
        loadDashboardData();
    });
    
    // Set up filter buttons
    document.getElementById('filterAll').addEventListener('click', function() {
        loadTransactions('all');
    });
    
    document.getElementById('filterFraudulent').addEventListener('click', function() {
        loadTransactions('fraudulent');
    });
    
    document.getElementById('filterSuspicious').addEventListener('click', function() {
        loadTransactions('suspicious');
    });
    
    // Set up transaction action buttons
    document.getElementById('flagTransaction').addEventListener('click', function() {
        const transactionId = this.getAttribute('data-transaction-id');
        updateTransactionStatus(transactionId, 'fraudulent');
    });
    
    document.getElementById('approveTransaction').addEventListener('click', function() {
        const transactionId = this.getAttribute('data-transaction-id');
        updateTransactionStatus(transactionId, 'approved');
    });
    
    // Load dashboard data
    function loadDashboardData() {
        // Load summary statistics
        fetch('/api/dashboard/summary')
            .then(response => response.json())
            .then(data => {
                updateSummaryCards(data);
            })
            .catch(error => console.error('Error loading summary data:', error));
        
        // Load fraud trends
        fetch('/api/dashboard/fraud-trends')
            .then(response => response.json())
            .then(data => {
                updateFraudTrendsChart(data);
            })
            .catch(error => console.error('Error loading fraud trends:', error));
        
        // Load risk factors
        fetch('/api/dashboard/risk-factors')
            .then(response => response.json())
            .then(data => {
                updateRiskFactorsChart(data);
                updateTopRiskFactors(data.top_factors);
            })
            .catch(error => console.error('Error loading risk factors:', error));
        
        // Load geographic hotspots
        fetch('/api/dashboard/geographic-hotspots')
            .then(response => response.json())
            .then(data => {
                updateGeographicHotspots(data);
            })
            .catch(error => console.error('Error loading geographic hotspots:', error));
        
        // Load transactions
        loadTransactions('all');
    }
    
    // Update summary cards
    function updateSummaryCards(data) {
        document.getElementById('totalTransactions').textContent = data.total_transactions;
        document.getElementById('fraudulentTransactions').textContent = data.fraudulent_transactions;
        document.getElementById('suspiciousTransactions').textContent = data.suspicious_transactions;
        document.getElementById('fraudDetectionRate').textContent = data.fraud_detection_rate + '%';
    }
    
    // Update fraud trends chart
    function updateFraudTrendsChart(data) {
        const ctx = document.getElementById('fraudTrendsChart').getContext('2d');
        
        if (fraudTrendsChart) {
            fraudTrendsChart.destroy();
        }
        
        fraudTrendsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.dates,
                datasets: [
                    {
                        label: 'Total Transactions',
                        data: data.total_transactions,
                        borderColor: 'rgb(54, 162, 235)',
                        tension: 0.1
                    },
                    {
                        label: 'Fraudulent Transactions',
                        data: data.fraudulent_transactions,
                        borderColor: 'rgb(255, 99, 132)',
                        tension: 0.1
                    },
                    {
                        label: 'Suspicious Transactions',
                        data: data.suspicious_transactions,
                        borderColor: 'rgb(255, 205, 86)',
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Update risk factors chart
    function updateRiskFactorsChart(data) {
        const ctx = document.getElementById('riskFactorsChart').getContext('2d');
        
        if (riskFactorsChart) {
            riskFactorsChart.destroy();
        }
        
        riskFactorsChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(153, 102, 255)'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
    }
    
    // Update top risk factors list
    function updateTopRiskFactors(factors) {
        const container = document.getElementById('topRiskFactors');
        container.innerHTML = '';
        
        factors.forEach(factor => {
            const item = document.createElement('li');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            item.innerHTML = `
                ${factor.name}
                <span class="badge bg-primary rounded-pill">${factor.count}</span>
            `;
            container.appendChild(item);
        });
    }
    
    // Update geographic hotspots list
    function updateGeographicHotspots(hotspots) {
        const container = document.getElementById('geographicHotspots');
        container.innerHTML = '';
        
        hotspots.forEach(spot => {
            const item = document.createElement('li');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            item.innerHTML = `
                ${spot.location}
                <span class="badge bg-danger rounded-pill">${spot.fraud_count}</span>
            `;
            container.appendChild(item);
        });
    }
    
    // Load transactions
    function loadTransactions(filter) {
        fetch(`/api/transactions?filter=${filter}`)
            .then(response => response.json())
            .then(data => {
                updateTransactionsTable(data);
            })
            .catch(error => console.error('Error loading transactions:', error));
    }
    
    // Update transactions table
    function updateTransactionsTable(transactions) {
        const tbody = document.getElementById('transactionsTableBody');
        tbody.innerHTML = '';
        
        transactions.forEach(transaction => {
            const row = document.createElement('tr');
            
            // Determine status badge class
            let statusClass = 'bg-success';
            if (transaction.is_fraudulent) {
                statusClass = 'bg-danger';
            } else if (transaction.fraud_probability > 0.5) {
                statusClass = 'bg-warning';
            }
            
            row.innerHTML = `
                <td>${transaction.transaction_id}</td>
                <td>${transaction.customer_name}</td>
                <td>$${transaction.amount.toFixed(2)}</td>
                <td>${transaction.location}</td>
                <td>${transaction.merchant}</td>
                <td>${(transaction.fraud_probability * 100).toFixed(1)}%</td>
                <td><span class="badge ${statusClass}">${transaction.status}</span></td>
                <td>
                    <button class="btn btn-sm btn-primary view-details" data-transaction-id="${transaction.transaction_id}">
                        <i class="bi bi-eye"></i>
                    </button>
                </td>
            `;
            
            tbody.appendChild(row);
        });
        
        // Add event listeners to view details buttons
        document.querySelectorAll('.view-details').forEach(button => {
            button.addEventListener('click', function() {
                const transactionId = this.getAttribute('data-transaction-id');
                showTransactionDetails(transactionId);
            });
        });
    }
    
    // Show transaction details modal
    function showTransactionDetails(transactionId) {
        fetch(`/api/transactions/${transactionId}`)
            .then(response => response.json())
            .then(data => {
                // Update modal fields
                document.getElementById('modalTransactionId').textContent = data.transaction_id;
                document.getElementById('modalAmount').textContent = `$${data.amount.toFixed(2)}`;
                document.getElementById('modalDate').textContent = new Date(data.created_at).toLocaleString();
                document.getElementById('modalLocation').textContent = data.location;
                document.getElementById('modalMerchant').textContent = data.merchant;
                
                document.getElementById('modalCustomerName').textContent = data.customer_name;
                document.getElementById('modalEmail').textContent = data.email;
                document.getElementById('modalPhone').textContent = data.phone;
                document.getElementById('modalCNIC').textContent = data.cnic;
                
                document.getElementById('modalRiskScore').textContent = `${(data.fraud_probability * 100).toFixed(1)}%`;
                document.getElementById('modalFraudProbability').textContent = `${(data.fraud_probability * 100).toFixed(1)}%`;
                document.getElementById('modalStatus').textContent = data.status;
                document.getElementById('modalDecision').textContent = data.decision;
                
                // Update risk factors
                const riskFactorsContainer = document.getElementById('modalRiskFactors');
                riskFactorsContainer.innerHTML = '';
                
                Object.entries(data.risk_factors).forEach(([factor, value]) => {
                    if (value) {
                        const item = document.createElement('li');
                        item.className = 'list-group-item list-group-item-danger';
                        item.textContent = factor.replace(/_/g, ' ').toUpperCase();
                        riskFactorsContainer.appendChild(item);
                    }
                });
                
                // Update transaction history
                const historyContainer = document.getElementById('modalTransactionHistory');
                historyContainer.innerHTML = '';
                
                data.transaction_history.forEach(history => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${new Date(history.created_at).toLocaleString()}</td>
                        <td>$${history.amount.toFixed(2)}</td>
                        <td>${history.merchant}</td>
                        <td><span class="badge ${history.is_fraudulent ? 'bg-danger' : 'bg-success'}">${history.status}</span></td>
                    `;
                    historyContainer.appendChild(row);
                });
                
                // Update action buttons
                document.getElementById('flagTransaction').setAttribute('data-transaction-id', transactionId);
                document.getElementById('approveTransaction').setAttribute('data-transaction-id', transactionId);
                
                // Show modal
                const modal = new bootstrap.Modal(document.getElementById('transactionDetailsModal'));
                modal.show();
            })
            .catch(error => console.error('Error loading transaction details:', error));
    }
    
    // Update transaction status
    function updateTransactionStatus(transactionId, status) {
        fetch(`/api/transactions/${transactionId}/status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: status })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('transactionDetailsModal'));
                modal.hide();
                
                // Refresh data
                loadDashboardData();
            } else {
                alert('Error updating transaction status: ' + data.message);
            }
        })
        .catch(error => console.error('Error updating transaction status:', error));
    }
}); 