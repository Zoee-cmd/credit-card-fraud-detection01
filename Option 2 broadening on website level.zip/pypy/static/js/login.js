document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Create FormData with correct field names
            const formData = new FormData();
            formData.append('email', this.querySelector('#loginEmail').value);
            formData.append('password', this.querySelector('#loginPassword').value);
            
            // Log the form data for debugging
            console.log('Login form data being sent:');
            for (let [key, value] of formData.entries()) {
                console.log(key + ': ' + value);
            }
            
            try {
                const response = await fetch('/login', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                
                // Log the response for debugging
                console.log('Login response status:', response.status);
                const data = await response.json();
                console.log('Login response data:', data);
                
                if (data.success) {
                    // Show success message
                    showAlert('success', 'Login successful! Redirecting...');
                    
                    // Clear form
                    loginForm.reset();
                    
                    // Redirect after a short delay
                    setTimeout(() => {
                        // Always redirect to customer dashboard on success
                        window.location.href = '/customer/dashboard';
                    }, 1000);
                } else {
                    showAlert('danger', data.message || 'Invalid email or password');
                }
            } catch (error) {
                console.error('An error occurred during login:', error);
                showAlert('danger', 'An error occurred during login. Please try again.');
            }
        });
    }
});

function showAlert(type, message) {
    // Remove any existing alerts
    const existingAlerts = document.querySelectorAll('#loginModal .alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Create new alert
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.role = "alert";
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Insert alert at the top of the modal body
    const modalBody = document.querySelector('#loginModal .modal-body');
    if (modalBody) {
        modalBody.insertBefore(alertDiv, modalBody.firstChild);
        
        // Make sure the alert is visible
        alertDiv.style.display = 'block';
        alertDiv.style.opacity = '1';
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            alertDiv.classList.remove('show');
            setTimeout(() => alertDiv.remove(), 150);
        }, 5000);
    } else {
        console.error('Modal body not found');
    }
} 