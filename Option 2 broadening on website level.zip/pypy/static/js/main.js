document.addEventListener('DOMContentLoaded', function() {
    const transactionForm = document.getElementById('transactionForm');
    const resultsDiv = document.getElementById('results');
    const noResultsDiv = document.getElementById('noResults');
    const resultAlert = document.getElementById('resultAlert');
    const resultTitle = document.getElementById('resultTitle');
    const resultDetails = document.getElementById('resultDetails');
    const probabilityBar = document.getElementById('probabilityBar');
    const timestamp = document.getElementById('timestamp');

    transactionForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = {
            amount: parseFloat(document.getElementById('amount').value),
            location: document.getElementById('location').value,
            merchant: document.getElementById('merchant').value
        };

        try {
            const response = await fetch('/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (response.ok) {
                displayResults(data);
            } else {
                throw new Error(data.error || 'An error occurred');
            }
        } catch (error) {
            displayError(error.message);
        }
    });

    function displayResults(data) {
        resultsDiv.classList.remove('d-none');
        noResultsDiv.classList.add('d-none');

        const isFraud = data.prediction === 1;
        const probability = data.probability * 100;

        resultAlert.className = 'alert';
        if (isFraud) {
            resultAlert.classList.add('alert-danger');
            resultTitle.textContent = '⚠️ Suspicious Transaction Detected';
            resultDetails.textContent = 'This transaction has been flagged as potentially fraudulent.';
        } else {
            resultAlert.classList.add('alert-success');
            resultTitle.textContent = '✅ Transaction Approved';
            resultDetails.textContent = 'This transaction appears to be legitimate.';
        }

        probabilityBar.style.width = `${probability}%`;
        probabilityBar.className = 'progress-bar';
        if (probability > 70) {
            probabilityBar.classList.add('bg-danger');
        } else if (probability > 30) {
            probabilityBar.classList.add('bg-warning');
        } else {
            probabilityBar.classList.add('bg-success');
        }

        timestamp.textContent = `Analysis Time: ${data.timestamp}`;
    }

    function displayError(message) {
        resultsDiv.classList.remove('d-none');
        noResultsDiv.classList.add('d-none');

        resultAlert.className = 'alert alert-danger';
        resultTitle.textContent = '❌ Error';
        resultDetails.textContent = message;
        probabilityBar.style.width = '0%';
        timestamp.textContent = '';
    }
});

// Dark Mode Functionality
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon();
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon();
    
    // Send theme preference to server
    fetch('/api/theme', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ theme: newTheme })
    });
}

function updateThemeIcon() {
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        themeToggle.innerHTML = currentTheme === 'light' 
            ? '<i class="bi bi-moon-fill"></i>' 
            : '<i class="bi bi-sun-fill"></i>';
    }
}

// Payment Preview Functionality
function initPaymentPreview() {
    const amountInput = document.querySelector('input[name="amount"]');
    const descriptionInput = document.querySelector('textarea[name="description"]');
    const expiryInput = document.querySelector('input[name="expiry_date"]');
    
    if (amountInput) {
        amountInput.addEventListener('input', updatePaymentPreview);
    }
    if (descriptionInput) {
        descriptionInput.addEventListener('input', updatePaymentPreview);
    }
    if (expiryInput) {
        expiryInput.addEventListener('input', updatePaymentPreview);
    }
}

function updatePaymentPreview() {
    const amount = document.querySelector('input[name="amount"]')?.value || '0.00';
    const description = document.querySelector('textarea[name="description"]')?.value || 'No description provided';
    const expiryDate = document.querySelector('input[name="expiry_date"]')?.value;
    
    const previewContainer = document.querySelector('.payment-preview');
    if (!previewContainer) return;
    
    const formattedAmount = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
    
    const formattedExpiry = expiryDate 
        ? new Date(expiryDate).toLocaleString()
        : 'No expiry date';
    
    previewContainer.innerHTML = `
        <div class="preview-header">
            <h5 class="mb-0">Payment Link Preview</h5>
        </div>
        <div class="preview-details">
            <div class="amount">${formattedAmount}</div>
            <div class="description">${description}</div>
            <div class="expiry">Expires: ${formattedExpiry}</div>
        </div>
        <div class="preview-footer">
            <span class="status active">Active</span>
        </div>
    `;
    
    previewContainer.style.display = amount > 0 ? 'block' : 'none';
}

// Copy to Clipboard Functionality
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        const tooltip = document.createElement('div');
        tooltip.className = 'alert alert-success position-fixed top-0 start-50 translate-middle-x mt-3';
        tooltip.style.zIndex = '9999';
        tooltip.textContent = 'Link copied to clipboard!';
        document.body.appendChild(tooltip);
        
        setTimeout(() => {
            tooltip.remove();
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy text: ', err);
    });
}

// Initialize everything when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initPaymentPreview();
    
    // Add theme toggle button to navbar if it doesn't exist
    const navbar = document.querySelector('.navbar-nav');
    if (navbar && !document.querySelector('.theme-toggle')) {
        const themeToggle = document.createElement('li');
        themeToggle.className = 'nav-item';
        themeToggle.innerHTML = `
            <button class="nav-link theme-toggle" onclick="toggleTheme()">
                <i class="bi bi-moon-fill"></i>
            </button>
        `;
        navbar.appendChild(themeToggle);
    }
}); 