document.addEventListener('DOMContentLoaded', function() {
    const paymentForm = document.getElementById('paymentForm');

    paymentForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = {
            name: document.getElementById('name').value,
            phone: document.getElementById('phone').value,
            cnic: document.getElementById('cnic').value,
            email: document.getElementById('email').value,
            billingAddress: document.getElementById('billingAddress').value,
            shippingAddress: document.getElementById('shippingAddress').value,
            cardNumber: document.getElementById('cardNumber').value,
            expiryDate: document.getElementById('expiryDate').value,
            cvv: document.getElementById('cvv').value
        };

        try {
            const response = await fetch('/payment/process', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (response.ok) {
                showSuccessMessage('Payment processed successfully!');
            } else {
                showErrorMessage(data.rules_violated);
            }
        } catch (error) {
            showErrorMessage(['An error occurred while processing the payment']);
        }
    });

    function showSuccessMessage(message) {
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-success mt-3';
        alertDiv.textContent = message;
        
        paymentForm.appendChild(alertDiv);
        
        setTimeout(() => {
            alertDiv.remove();
            window.location.href = '/payment/success';
        }, 3000);
    }

    function showErrorMessage(rules) {
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-danger mt-3';
        
        const message = document.createElement('p');
        message.textContent = 'Payment was declined due to the following reasons:';
        
        const list = document.createElement('ul');
        rules.forEach(rule => {
            const item = document.createElement('li');
            item.textContent = rule;
            list.appendChild(item);
        });
        
        alertDiv.appendChild(message);
        alertDiv.appendChild(list);
        
        paymentForm.appendChild(alertDiv);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }

    // Input validation
    document.getElementById('cardNumber').addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        value = value.replace(/(\d{4})/g, '$1 ').trim();
        e.target.value = value;
    });

    document.getElementById('expiryDate').addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length >= 2) {
            value = value.slice(0, 2) + '/' + value.slice(2);
        }
        e.target.value = value;
    });

    document.getElementById('cvv').addEventListener('input', function(e) {
        e.target.value = e.target.value.replace(/\D/g, '').slice(0, 3);
    });
}); 