document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Check if terms are accepted
            const termsCheckbox = this.querySelector('#terms');
            if (termsCheckbox && !termsCheckbox.checked) {
                showAlert('danger', 'You must agree to the Terms and Conditions.');
                return;
            }
            
            // Check if passwords match
            const password = this.querySelector('#registerPassword').value;
            const confirmPassword = this.querySelector('#registerConfirmPassword').value;
            
            if (password !== confirmPassword) {
                showAlert('danger', 'Passwords do not match.');
                return;
            }
            
            // Create FormData with correct field names
            const formData = new FormData();
            formData.append('username', this.querySelector('#registerUsername').value);
            formData.append('email', this.querySelector('#registerEmail').value);
            formData.append('password', password);
            formData.append('confirm_password', confirmPassword);
            formData.append('phone', this.querySelector('#registerPhone').value);
            formData.append('cnic', this.querySelector('#registerCNIC').value);
            formData.append('address', this.querySelector('#registerAddress').value);
            
            // Log the form data for debugging
            console.log('Form data being sent:');
            for (let [key, value] of formData.entries()) {
                console.log(key + ': ' + value);
            }
            
            try {
                const response = await fetch('/register', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });
                
                // Log the response for debugging
                console.log('Response status:', response.status);
                const data = await response.json();
                console.log('Response data:', data);
                
                if (data.success) {
                    // Show success message
                    showAlert('success', 'Registration successful! Please login.');
                    
                    // Clear form
                    registerForm.reset();
                    
                    // Redirect to login page after a short delay
                    setTimeout(() => {
                        window.location.href = data.redirect || '/login';
                    }, 2000);
                } else {
                    showAlert('danger', data.message || 'Registration failed. Please try again.');
                }
            } catch (error) {
                console.error('An error occurred during registration:', error);
                showAlert('danger', 'An error occurred during registration. Please try again.');
            }
        });
    }
});

function showAlert(type, message) {
    // Remove any existing alerts
    const existingAlerts = document.querySelectorAll('#registerModal .alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Create new alert
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert alert at the top of the modal body
    const modalBody = document.querySelector('#registerModal .modal-body');
    modalBody.insertBefore(alertDiv, modalBody.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => alertDiv.remove(), 150);
    }, 5000);
} 