// Dark mode functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check for saved theme preference or use system preference
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }
    
    // Add theme toggle button to navbar if it doesn't exist
    const navbarNav = document.querySelector('.navbar-nav');
    if (navbarNav && !document.querySelector('.theme-toggle')) {
        const themeToggle = document.createElement('li');
        themeToggle.className = 'nav-item theme-toggle';
        themeToggle.innerHTML = '<i class="bi bi-moon-fill"></i>';
        themeToggle.addEventListener('click', toggleTheme);
        navbarNav.prepend(themeToggle);
    }
    
    // Update theme toggle icon
    updateThemeIcon();
    
    // Payment link preview functionality
    const amountInput = document.getElementById('amount');
    const descriptionInput = document.getElementById('description');
    const expiryDateInput = document.getElementById('expiry_date');
    
    if (amountInput && descriptionInput && expiryDateInput) {
        // Create preview container if it doesn't exist
        if (!document.getElementById('payment-preview-container')) {
            const previewContainer = document.createElement('div');
            previewContainer.id = 'payment-preview-container';
            previewContainer.className = 'payment-preview';
            previewContainer.style.display = 'none';
            
            previewContainer.innerHTML = `
                <div class="payment-preview-header">
                    <div class="payment-preview-title">Payment Link Preview</div>
                    <div class="payment-preview-amount">$0.00</div>
                </div>
                <div class="payment-preview-details">
                    <div class="payment-preview-detail-item">
                        <span class="payment-preview-detail-label">Description</span>
                        <span class="payment-preview-detail-value" id="preview-description">-</span>
                    </div>
                    <div class="payment-preview-detail-item">
                        <span class="payment-preview-detail-label">Expiry Date</span>
                        <span class="payment-preview-detail-value" id="preview-expiry">-</span>
                    </div>
                </div>
                <div class="payment-preview-footer">
                    <span class="payment-preview-status active">Active</span>
                    <span class="payment-preview-link" id="preview-link">-</span>
                </div>
            `;
            
            // Insert after the form
            const form = document.querySelector('form');
            if (form) {
                form.parentNode.insertBefore(previewContainer, form.nextSibling);
            }
        }
        
        // Add event listeners for preview updates
        amountInput.addEventListener('input', updatePaymentPreview);
        descriptionInput.addEventListener('input', updatePaymentPreview);
        expiryDateInput.addEventListener('input', updatePaymentPreview);
        
        // Initial preview update
        updatePaymentPreview();
    }
});

// Toggle between light and dark themes
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    updateThemeIcon();
}

// Update the theme toggle icon based on current theme
function updateThemeIcon() {
    const themeToggle = document.querySelector('.theme-toggle i');
    if (themeToggle) {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        if (currentTheme === 'dark') {
            themeToggle.className = 'bi bi-sun-fill';
        } else {
            themeToggle.className = 'bi bi-moon-fill';
        }
    }
}

// Update payment link preview
function updatePaymentPreview() {
    const previewContainer = document.getElementById('payment-preview-container');
    if (!previewContainer) return;
    
    const amount = document.getElementById('amount').value;
    const description = document.getElementById('description').value;
    const expiryDate = document.getElementById('expiry_date').value;
    
    // Update amount
    const amountElement = previewContainer.querySelector('.payment-preview-amount');
    if (amountElement) {
        amountElement.textContent = amount ? `$${parseFloat(amount).toFixed(2)}` : '$0.00';
    }
    
    // Update description
    const descriptionElement = document.getElementById('preview-description');
    if (descriptionElement) {
        descriptionElement.textContent = description || '-';
    }
    
    // Update expiry date
    const expiryElement = document.getElementById('preview-expiry');
    if (expiryElement) {
        if (expiryDate) {
            const date = new Date(expiryDate);
            expiryElement.textContent = date.toLocaleString();
        } else {
            expiryElement.textContent = 'No expiry';
        }
    }
    
    // Show/hide preview based on whether there's an amount
    previewContainer.style.display = amount ? 'block' : 'none';
    
    // Generate a sample link token (in a real app, this would be generated by the server)
    const linkElement = document.getElementById('preview-link');
    if (linkElement) {
        if (amount) {
            // This is just a placeholder - in a real app, the actual link would be generated by the server
            linkElement.textContent = `${window.location.origin}/payment/sample-token`;
        } else {
            linkElement.textContent = '-';
        }
    }
} 
document.addEventListener('DOMContentLoaded', function() {
    // Check for saved theme preference or use system preference
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }
    
    // Add theme toggle button to navbar if it doesn't exist
    const navbarNav = document.querySelector('.navbar-nav');
    if (navbarNav && !document.querySelector('.theme-toggle')) {
        const themeToggle = document.createElement('li');
        themeToggle.className = 'nav-item theme-toggle';
        themeToggle.innerHTML = '<i class="bi bi-moon-fill"></i>';
        themeToggle.addEventListener('click', toggleTheme);
        navbarNav.prepend(themeToggle);
    }
    
    // Update theme toggle icon
    updateThemeIcon();
    
    // Payment link preview functionality
    const amountInput = document.getElementById('amount');
    const descriptionInput = document.getElementById('description');
    const expiryDateInput = document.getElementById('expiry_date');
    
    if (amountInput && descriptionInput && expiryDateInput) {
        // Create preview container if it doesn't exist
        if (!document.getElementById('payment-preview-container')) {
            const previewContainer = document.createElement('div');
            previewContainer.id = 'payment-preview-container';
            previewContainer.className = 'payment-preview';
            previewContainer.style.display = 'none';
            
            previewContainer.innerHTML = `
                <div class="payment-preview-header">
                    <div class="payment-preview-title">Payment Link Preview</div>
                    <div class="payment-preview-amount">$0.00</div>
                </div>
                <div class="payment-preview-details">
                    <div class="payment-preview-detail-item">
                        <span class="payment-preview-detail-label">Description</span>
                        <span class="payment-preview-detail-value" id="preview-description">-</span>
                    </div>
                    <div class="payment-preview-detail-item">
                        <span class="payment-preview-detail-label">Expiry Date</span>
                        <span class="payment-preview-detail-value" id="preview-expiry">-</span>
                    </div>
                </div>
                <div class="payment-preview-footer">
                    <span class="payment-preview-status active">Active</span>
                    <span class="payment-preview-link" id="preview-link">-</span>
                </div>
            `;
            
            // Insert after the form
            const form = document.querySelector('form');
            if (form) {
                form.parentNode.insertBefore(previewContainer, form.nextSibling);
            }
        }
        
        // Add event listeners for preview updates
        amountInput.addEventListener('input', updatePaymentPreview);
        descriptionInput.addEventListener('input', updatePaymentPreview);
        expiryDateInput.addEventListener('input', updatePaymentPreview);
        
        // Initial preview update
        updatePaymentPreview();
    }
});

// Toggle between light and dark themes
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    updateThemeIcon();
}

// Update the theme toggle icon based on current theme
function updateThemeIcon() {
    const themeToggle = document.querySelector('.theme-toggle i');
    if (themeToggle) {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        if (currentTheme === 'dark') {
            themeToggle.className = 'bi bi-sun-fill';
        } else {
            themeToggle.className = 'bi bi-moon-fill';
        }
    }
}

// Update payment link preview
function updatePaymentPreview() {
    const previewContainer = document.getElementById('payment-preview-container');
    if (!previewContainer) return;
    
    const amount = document.getElementById('amount').value;
    const description = document.getElementById('description').value;
    const expiryDate = document.getElementById('expiry_date').value;
    
    // Update amount
    const amountElement = previewContainer.querySelector('.payment-preview-amount');
    if (amountElement) {
        amountElement.textContent = amount ? `$${parseFloat(amount).toFixed(2)}` : '$0.00';
    }
    
    // Update description
    const descriptionElement = document.getElementById('preview-description');
    if (descriptionElement) {
        descriptionElement.textContent = description || '-';
    }
    
    // Update expiry date
    const expiryElement = document.getElementById('preview-expiry');
    if (expiryElement) {
        if (expiryDate) {
            const date = new Date(expiryDate);
            expiryElement.textContent = date.toLocaleString();
        } else {
            expiryElement.textContent = 'No expiry';
        }
    }
    
    // Show/hide preview based on whether there's an amount
    previewContainer.style.display = amount ? 'block' : 'none';
    
    // Generate a sample link token (in a real app, this would be generated by the server)
    const linkElement = document.getElementById('preview-link');
    if (linkElement) {
        if (amount) {
            // This is just a placeholder - in a real app, the actual link would be generated by the server
            linkElement.textContent = `${window.location.origin}/payment/sample-token`;
        } else {
            linkElement.textContent = '-';
        }
    }
} 